- [SWC-registry](https://github.com/SmartContractSecurity/SWC-registry/) - SWC definitions and a
  large repository of crafted and real-world samples of vulnerable smart contracts.
- [SWC Pages](https://smartcontractsecurity.github.io/SWC-registry/) - The SWC-registry repo
  published on Github Pages