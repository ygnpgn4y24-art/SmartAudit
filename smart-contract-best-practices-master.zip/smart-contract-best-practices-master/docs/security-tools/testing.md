- [solidity-coverage](https://github.com/sc-forks/solidity-coverage) - Code coverage for Solidity
  testing.
- [solidity-shell](https://github.com/tintinweb/solidity-shell) - An interactive Solidity shell with lightweight session recording and remote compiler support.
- [chisel](https://github.com/foundry-rs/foundry/tree/master/chisel) - Chisel is a fast, utilitarian, and verbose solidity REPL. It is heavily inspired by the incredible work done in soli and solidity-shell!
- [soli](https://github.com/jpopesculian/soli) - Solidity REPL
